let name = prompt('Your name please?')
let age = prompt('Your age please?')

if( age >= 20 && age <= 35 ){
    console.log(`Hi ${name}, You are welcome.`)
}else{
    console.log(`Hi ${name}, You are not allowed. We are sorry.`)
}